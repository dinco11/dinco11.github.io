﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace pmc
{
    public partial class AdminAccount : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
            lblWelcome.Visible = false;
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=POTATO;Initial Catalog=petishclinic;Integrated Security=True"))
            {
                sqlCon.Open();
                string query = "SELECT COUNT(1) FROM Register WHERE password=@password";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);

                sqlCmd.Parameters.AddWithValue("@password", txtPassword.Text.Trim());
                int count = Convert.ToInt32(sqlCmd.ExecuteScalar());
                if (count == 1)
                {
                    Session["password"] = txtPassword.Text.Trim();
                    Response.Redirect("AdminPage.aspx");
                }
                else
                {
                    Response.Redirect("AdminPage.aspx");
                    lblWelcome.Visible = true;
                }
            }
        }


        protected void ImageButton_Home_Click1(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("Homie.aspx");
        }

      
    }
}