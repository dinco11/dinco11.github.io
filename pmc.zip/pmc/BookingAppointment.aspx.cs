﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace pmc
{
    public partial class BookingAppointment : System.Web.UI.Page
    {
        SqlCommand cmd = new SqlCommand();
        SqlConnection con = new SqlConnection();
        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
            con.ConnectionString = ConfigurationManager.ConnectionStrings["petishclinicConnectionString"].ConnectionString;
            con.Open();
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            txtDnT.Text = (Calendar1.SelectedDate.ToLongDateString() + " " + txtTime.Text).ToString();
        }

        protected void Btn_SelectDate_Click(object sender, EventArgs e)
        {
            Calendar1.Visible = true;
        }

        protected void Btn_BookAppnt_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["petishclinicConnectionString"].ConnectionString);
            conn.Open();
            SqlCommand appointmentCheckUser = new SqlCommand("Select Date From BookApp Where Date='" + txtDnT.Text + "' and Time='" + txtTime.Text + "' and Purpose='" + DropDownList3.SelectedValue + "'", conn);
            SqlDataAdapter sd = new SqlDataAdapter(appointmentCheckUser);
            DataTable datadt = new DataTable();
            sd.Fill(datadt);
            if (datadt.Rows.Count > 0)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "alert('SLOT ALREADY TAKEN, PLEASE BOOK ANOTHER DAY');", true);
            }
            else
            {


                SqlCommand cmd = new SqlCommand("INSERT INTO BookApp (Date,Time,PetName,OwnerName,Email,Pet_Type,Purpose)values(@Date,@Time,@PetName,@OwnerName,@Email,@Pet_Type,@Purpose)", con);

                cmd.Parameters.AddWithValue("@Date", txtDnT.Text);
                cmd.Parameters.AddWithValue("@Time", txtTime.Text);
                cmd.Parameters.AddWithValue("@PetName", txtPN.Text);
                cmd.Parameters.AddWithValue("@OwnerName", txtON.Text);
                cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                cmd.Parameters.AddWithValue("@Pet_Type", DropDownList2.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@Purpose", DropDownList3.SelectedItem.ToString());

                cmd.ExecuteNonQuery();
                cmd.ExecuteScalar();

                con.Close();


                if (Calendar1.SelectedDate > Calendar1.TodaysDate)
                {
                    Lbl_Mssg.Text = "<br>PetName:" + txtPN.Text + "<br>OwnerName:" + txtON.Text + "<br>Email:" + txtEmail.Text + "<br>Pet_Type:" + DropDownList2.SelectedValue.ToString() + "<br>Purpose:" + DropDownList3.SelectedValue.ToString() + "<br> Your Appointment Booked on" + Calendar1.SelectedDate.ToLongDateString() + txtTime.Text;
                }
                else
                {
                    Lbl_Mssg.Text = "SORRY! Your Appointment is not available on" + Calendar1.SelectedDate.ToLongDateString();
                }

            }
        }

        protected void ImageButton_Home_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("Userpage.aspx");
        }

        protected void Calendar1_DayRender(object sender, DayRenderEventArgs e)
        {
            if (!e.Day.IsOtherMonth && e.Day.IsWeekend)
            {
                e.Day.IsSelectable = false;
                e.Cell.ForeColor = System.Drawing.Color.Red;
                e.Cell.Font.Strikeout = true;
                e.Cell.ToolTip = "Not Available for Booking";
            }
            else
            {
                e.Cell.ToolTip = "Available";
            }

        }


    }
}
