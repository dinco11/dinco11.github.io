﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pmc
{
    public partial class Homie : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void ImageButton_About_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("About.aspx");
        }

        protected void ImageButton_Login_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("SignHere.aspx");
        }

        protected void ImageButton_Services_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("Services.aspx");
        }

        protected void ImageButton_Contact_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("Contact.aspx");
        }
    }
}