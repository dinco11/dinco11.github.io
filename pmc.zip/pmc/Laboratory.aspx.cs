﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace pmc
{
    public partial class Laboratory : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
        }
        protected void lbInsert_Click(object sender, EventArgs e)
        {
            SqlDataSource1.InsertParameters["TestName"].DefaultValue =
                ((TextBox)GridView1.FooterRow.FindControl("txtTestName")).Text;

            SqlDataSource1.InsertParameters["TestCost"].DefaultValue =
                ((TextBox)GridView1.FooterRow.FindControl("txtTestCost")).Text;
            SqlDataSource1.Insert();
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("AdminPage.aspx");
        }
    }
}