﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;

namespace pmc
{
    public partial class Prescription : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)

        {
            this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
        }
        protected void lbInsert_Click(object sender, EventArgs e)
        {
            SqlDataSource1.InsertParameters["DocName"].DefaultValue =
                ((TextBox)GridView2.FooterRow.FindControl("txtDocName")).Text;

            SqlDataSource1.InsertParameters["PetName"].DefaultValue =
                ((TextBox)GridView2.FooterRow.FindControl("txtPetName")).Text;
            SqlDataSource1.Insert();
            SqlDataSource1.InsertParameters["TestName"].DefaultValue =
                ((TextBox)GridView2.FooterRow.FindControl("txtTestName")).Text;
            SqlDataSource1.Insert();
            SqlDataSource1.InsertParameters["Medicine"].DefaultValue =
                ((TextBox)GridView2.FooterRow.FindControl("txtMedicine")).Text;
            SqlDataSource1.Insert();
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("AdminPage.aspx");
        }
    }

}