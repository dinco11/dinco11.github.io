﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace pmc
{
    public partial class Registration1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
        }


        protected void Button_Submit_Click1(object sender, EventArgs e)
        {


            SqlConnection conn = new SqlConnection("Data Source = POTATO; Initial Catalog = petishclinic; Integrated Security = True");
            conn.Open();
            SqlCommand commToCheckUser = new SqlCommand("Select Username From Register Where Username ='" + TBUsername.Text + "' and Email='" + TBEmail.Text + "'", conn);
            SqlDataAdapter sd = new SqlDataAdapter(commToCheckUser);
            DataTable dt = new DataTable();
            sd.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "alert('Already Exist');", true);
            }
            else
            {


                SqlCommand cmd = new SqlCommand(@"INSERT INTO Register(Firstname,Lastname,Username,Email,Password,ConfirmPassword,Petname) VALUES(@Firstname,@Lastname,@Username,@Email,@Password,@ConfirmPassword,@Petname)", conn);
                cmd.Parameters.AddWithValue("@Firstname", TBFirstname.Text);
                cmd.Parameters.AddWithValue("@Lastname", TBLastname.Text);
                cmd.Parameters.AddWithValue("@Username", TBUsername.Text);
                cmd.Parameters.AddWithValue("@Email", TBEmail.Text);
                cmd.Parameters.AddWithValue("@Password", TBPass.Text);
                cmd.Parameters.AddWithValue("@ConfirmPassword", TBRPass.Text);
                cmd.Parameters.AddWithValue("@Petname", TBPetname.Text);

                cmd.ExecuteNonQuery();
                conn.Close();

                Response.Redirect("SignHere.aspx");
            }


        }
    }

}