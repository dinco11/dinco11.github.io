﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace pmc
{
    public partial class Sendmail : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress("YourGmailID@gmail.com");
                mailMessage.To.Add("jennyadlao22@gmail.com");
                mailMessage.Subject = txtSubject.Text;
                mailMessage.Body = "<b>Sender Name : </b>" + txtName.Text + "<br/>" + "<b>Sender Email : </b>" + txtEmail.Text + "<br/>" + "<b>Messages : </b>" + txtMessages.Text;
                mailMessage.IsBodyHtml = true;
                SmtpClient smtpClient = new SmtpClient("smtp.gmail.com", 587);
                smtpClient.EnableSsl = true;
                smtpClient.Credentials = new System.Net.NetworkCredential("jennyadlao22@gmail.com", "potato.1029");
                smtpClient.Send(mailMessage);
                lblMessage.ForeColor = System.Drawing.Color.Blue;
                lblMessage.Text = "Thank you for contacting us";
                txtName.Enabled = false;
                txtEmail.Enabled = false;
                txtMessages.Enabled = false;
                txtSubject.Enabled = false;
                Button1.Enabled = false;
            }
            catch (Exception)
            {
                // Log the exception information to 
                // database table or event viewer
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = "There is an unkwon problem. Please try later";
            }
        }


    }
}

